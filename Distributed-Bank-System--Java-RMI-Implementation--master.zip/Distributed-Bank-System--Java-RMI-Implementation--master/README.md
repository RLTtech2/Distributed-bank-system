# Distributed Bank System (Java RMI Implementation)
 A Distributed Bank system implemented in Java using RMI, Hibernate(ORM) and SQlite Database . App allows multiple distributed client softwares(ATM's) to communicate with the main server software in real time to update the changes. More info in the detailed ReadMe file.
